#!/usr/bin/env python3
"""Génère une vidéo YouTube horizontale (1920x1080) de ~3 min 20 à partir de scripts.json.

Étapes : choix du script -> voix off (edge-tts, gratuit) phrase par phrase -> montage des scènes animées
-> out/video.mp4 + out/thumbnail.png + out/meta.json (titre, description avec chapitres, tags).

    python build.py            # génération réelle (internet requis pour edge-tts)
    python build.py --dry      # test sans internet : voix remplacée par du silence
    python build.py --index 2  # force un script précis
    python build.py --dump 1,30,80   # enregistre des images de contrôle (sans encoder la vidéo)
"""
import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from engine import FPS, H, W, Renderer, make_thumbnail, split_sentences

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"
SEG = OUT / "seg"

LEAD = 0.5                      # silence avant la 1re phrase
OUTRO_HOLD = 3.5                # temps d'écran de fin après la dernière phrase
TARGET_TOTAL = float(os.environ.get("TARGET_SECONDS", "200"))   # 3 min 20 s
PAUSE_MIN, PAUSE_MAX = 0.30, 1.0
BRAND = os.environ.get("BRAND", "LE DÉCLIC")
SERIES = os.environ.get("SERIES", "Motivation")
VOICE = os.environ.get("TTS_VOICE", "fr-FR-HenriNeural")
TTS_RATE = os.environ.get("TTS_RATE", "+0%")


def run(cmd, quiet=False):
    if not quiet:
        print("+", " ".join(str(c) for c in cmd), flush=True)
    subprocess.run([str(c) for c in cmd], check=True)


def probe_duration(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1",
                        str(path)], capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


def tts_sentence(text, out, retries=4):
    import edge_tts
    last = None
    for attempt in range(retries):
        try:
            asyncio.run(edge_tts.Communicate(text, VOICE, rate=TTS_RATE).save(str(out)))
            if out.exists() and out.stat().st_size > 500:
                return
        except Exception as e:  # noqa: BLE001
            last = e
        time.sleep(2 * (attempt + 1))
    raise SystemExit(f"Synthèse vocale impossible : {last}")


def silence_mp3(seconds, out):
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "anullsrc=r=24000:cl=mono", "-t",
         f"{seconds:.2f}", "-q:a", "9", out], quiet=True)


def stamp(sec):
    sec = int(sec)
    return f"{sec // 60}:{sec % 60:02d}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--index", type=int, default=None)
    ap.add_argument("--dump", default=None)
    args = ap.parse_args()

    videos = json.loads((ROOT / "scripts.json").read_text(encoding="utf-8"))
    state_path = ROOT / "state.json"
    state = json.loads(state_path.read_text()) if state_path.exists() else {"next_index": 0}
    idx = (args.index if args.index is not None else state.get("next_index", 0)) % len(videos)
    video = videos[idx]
    print(f"Script #{idx} : {video['title']}")

    OUT.mkdir(exist_ok=True)
    SEG.mkdir(exist_ok=True)
    for f in SEG.glob("*"):
        f.unlink()

    # 1) voix : une phrase à la fois
    sentences = []      # (index de scène, texte)
    for si, sc in enumerate(video["scenes"]):
        for s in split_sentences(sc["voice"]):
            sentences.append((si, s))
    speech = []
    for i, (_, s) in enumerate(sentences):
        mp3 = SEG / f"{i:03d}.mp3"
        if args.dry:
            silence_mp3(max(0.8, len(s.split()) / 2.7), mp3)
        else:
            tts_sentence(s, mp3)
        speech.append(probe_duration(mp3))
    n = len(sentences)
    pause = (TARGET_TOTAL - LEAD - OUTRO_HOLD - sum(speech)) / n
    pause = max(PAUSE_MIN, min(PAUSE_MAX, pause))
    words = sum(len(s.split()) for _, s in sentences)
    print(f"{words} mots, voix {sum(speech):.1f}s, {n} phrases, pause {pause:.2f}s")

    # 2) audio : phrase + pause
    slots, lines = [], []
    for i in range(n):
        wav = SEG / f"{i:03d}.wav"
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", SEG / f"{i:03d}.mp3", "-af", f"apad=pad_dur={pause:.3f}",
             "-ar", "24000", "-ac", "1", wav], quiet=True)
        slots.append(probe_duration(wav))
        lines.append(f"file '{wav.as_posix()}'")
    (SEG / "list.txt").write_text("\n".join(lines), encoding="utf-8")
    voice = OUT / "voice.wav"
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", SEG / "list.txt", "-c", "copy",
         voice], quiet=True)

    # 3) chronologie des scènes et sous-titres
    t = LEAD
    captions, scene_times = [], {}
    for i, (si, s) in enumerate(sentences):
        captions.append({"start": t, "speech": speech[i], "text": s})
        a, b = scene_times.get(si, (t, t))
        scene_times[si] = (a, t + slots[i])
        t += slots[i]
    total = t + OUTRO_HOLD
    scenes = []
    for si, sc in enumerate(video["scenes"]):
        start = 0.0 if si == 0 else scenes[-1]["end"]
        end = total if si == len(video["scenes"]) - 1 else scene_times[si][1]
        d = dict(sc)
        d["start"], d["end"] = start, end
        scenes.append(d)
    print(f"Durée totale : {total:.1f}s ({stamp(total)})")

    r = Renderer(video.get("header", video["title"]), video.get("series", SERIES), BRAND, scenes, captions, total)
    if args.dump:
        dd = OUT / "dump"
        dd.mkdir(exist_ok=True)
        for tt in args.dump.split(","):
            r.frame(float(tt)).save(dd / f"t{float(tt):07.2f}.png")
        print("images de contrôle dans", dd)
        return

    # 4) encodage (images envoyées à ffmpeg au fil de l'eau) + musique facultative music.mp3
    out_video = OUT / "video.mp4"
    music = ROOT / "music.mp3"
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
           "-r", str(FPS), "-i", "-", "-i", str(voice)]
    graph = f"[1:a]adelay={int(LEAD * 1000)}:all=1,apad[v]"
    if music.exists():
        cmd += ["-stream_loop", "-1", "-i", str(music)]
        graph += (f";[2:a]volume=0.08,afade=t=in:st=0:d=3,afade=t=out:st={total - 4:.2f}:d=4[m]"
                  ";[v][m]amix=inputs=2:duration=first:normalize=0[a]")
    else:
        graph += ";[v]anull[a]"
    cmd += ["-filter_complex", graph, "-map", "0:v", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast",
            "-crf", "21", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-t", f"{total:.3f}",
            "-movflags", "+faststart", str(out_video)]
    print("+ ffmpeg (images animées)", flush=True)
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for k in range(int(total * FPS)):
            proc.stdin.write(r.frame(k / FPS).tobytes())
    finally:
        proc.stdin.close()
    if proc.wait() != 0:
        raise SystemExit("ffmpeg a échoué")

    # 5) miniature
    make_thumbnail(OUT / "thumbnail.png", video.get("thumb", video["title"]), BRAND, video.get("series", SERIES))

    # 6) métadonnées YouTube (chapitres automatiques)
    insights = json.loads((ROOT / "insights.json").read_text(encoding="utf-8"))
    chapters = []
    for si, sc in enumerate(scenes):
        if sc.get("chapter") or si == 0:
            chapters.append(f"{stamp(0 if si == 0 else sc['start'] + LEAD * 0)} {sc.get('chapter', 'Introduction')}")
    desc = (video.get("description", "") + "\n\n" + "\n".join(chapters) + "\n\n" +
            insights.get("description_footer", "") + "\n\n" + " ".join(insights.get("hashtags", []))).strip()
    meta = {
        "index": idx,
        "title": video["title"][:100],
        "description": desc,
        "tags": list(dict.fromkeys(video.get("tags", []) + insights.get("tags", []))),
        "privacy": "public",
        "duration_s": round(total, 1),
        "video": str(out_video),
        "thumbnail": str(OUT / "thumbnail.png"),
    }
    (OUT / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print("OK ->", out_video)


if __name__ == "__main__":
    main()
