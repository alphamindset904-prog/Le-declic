#!/usr/bin/env python3
"""Moteur de rendu YouTube 16:9 (1920x1080) pour la chaîne motivation.

Gabarit : en-tête fixe (série + titre + filet), ZONE CENTRALE = scène vectorielle animée,
filet, sous-titres « karaoké » (mots surlignés au rythme de la voix), barre de progression.
Types de scènes : hook, stat, bars, quote, rule, list, versus, outro.
Tout est dessiné image par image avec Pillow (sans fichier externe), déterministe.
"""
import math
import random
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

W, H = 1920, 1080
FPS = 24
S = 2                      # sur-échantillonnage des scènes (anticrénelage)
SCN_Y, SCN_H = 190, 640    # zone des scènes
CAP_Y = 870                # haut de la zone de sous-titres

BG_TOP, BG_BOT = (9, 10, 14), (25, 21, 19)
ACCENT = (255, 178, 52)
ACCENT_SOFT = (255, 216, 140)
WHITE = (246, 244, 238)
MUTED = (128, 130, 142)
DARK = (22, 22, 27)
PANEL = (31, 30, 36)

FONT_DIRS = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/Library/Fonts", "C:/Windows/Fonts"]


def find_font(names):
    for d in FONT_DIRS:
        for n in names:
            p = Path(d) / n
            if p.exists():
                return str(p)
    raise SystemExit("Police introuvable : installez fonts-dejavu-core")


FONT_FILES = {
    "serif": ["DejaVuSerif.ttf", "DejaVuSans.ttf", "arial.ttf"],
    "serifb": ["DejaVuSerif-Bold.ttf", "DejaVuSans-Bold.ttf", "arialbd.ttf"],
    "sans": ["DejaVuSans.ttf", "arial.ttf"],
    "sansb": ["DejaVuSans-Bold.ttf", "arialbd.ttf"],
}


class Fonts:
    def __init__(self):
        self.paths = {k: find_font(v) for k, v in FONT_FILES.items()}
        self.cache = {}

    def get(self, kind, size):
        key = (kind, int(size))
        if key not in self.cache:
            self.cache[key] = ImageFont.truetype(self.paths[kind], int(size))
        return self.cache[key]


# ------------------------------------------------------------------ outils
def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def smooth(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


def out_cubic(x):
    x = clamp(x)
    return 1 - (1 - x) ** 3


def out_back(x):
    x = clamp(x)
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def fmt_num(v, dec):
    return f"{v:.{dec}f}".replace(".", ",")


def parse_marked(text):
    """« Et si *1 %* suffisait ? » -> [(mot, accent), ...]"""
    toks, acc = [], False
    for w in text.split():
        if w.startswith("*"):
            acc = True
        clean = w.strip("*")
        if clean:
            toks.append((clean, acc))
        if w.endswith("*"):
            acc = False
    return toks


def split_sentences(text):
    return [p for p in re.split(r"(?<=[.!?])\s+", text.strip()) if p]


def glow_sprite(size, power=2.0):
    g = Image.radial_gradient("L").point(lambda v: max(0, int(255 - v * 255 / 180)))
    g = g.resize((size, size), Image.BILINEAR)
    return g.point(lambda v: int((v / 255) ** power * 255))


# ------------------------------------------------------------------- calque
class Layer:
    """Zone de scène dessinée en haute résolution (S fois), puis réduite."""

    def __init__(self, bg_rgb, w, h, fonts):
        self.w, self.h, self.fonts = w, h, fonts
        self.img = bg_rgb.resize((w * S, h * S), Image.BILINEAR)
        self.d = ImageDraw.Draw(self.img, "RGBA")

    def font(self, kind, size):
        return self.fonts.get(kind, size * S)

    def tw(self, s, font):
        return self.d.textlength(s, font=font) / S

    @staticmethod
    def col(c, a):
        return tuple(c) + (int(255 * clamp(a)),)

    def text(self, x, y, s, font, c, a=1.0, anchor="la", shadow=True):
        if a <= 0.01:
            return
        if shadow:
            self.d.text((x * S + 2 * S, y * S + 3 * S), s, font=font, fill=(0, 0, 0, int(150 * clamp(a))), anchor=anchor)
        self.d.text((x * S, y * S), s, font=font, fill=self.col(c, a), anchor=anchor)

    def tracked(self, cx, y, s, font, c, a=1.0, spacing=6):
        widths = [self.tw(ch, font) for ch in s]
        total = sum(widths) + spacing * (len(s) - 1)
        x = cx - total / 2
        for ch, w in zip(s, widths):
            self.text(x, y, ch, font, c, a, shadow=False)
            x += w + spacing

    def rect(self, x0, y0, x1, y1, c, a=1.0, r=0, outline=None, width=0):
        box = [x0 * S, y0 * S, x1 * S, y1 * S]
        fill = self.col(c, a) if c is not None else None
        oc = self.col(outline, a) if outline is not None else None
        if r:
            self.d.rounded_rectangle(box, radius=r * S, fill=fill, outline=oc, width=int(width * S))
        else:
            self.d.rectangle(box, fill=fill, outline=oc, width=int(width * S))

    def ellipse(self, cx, cy, rx, ry, c=None, a=1.0, outline=None, width=0):
        if rx <= 0 or ry <= 0:
            return
        fill = self.col(c, a) if c is not None else None
        oc = self.col(outline, a) if outline is not None else None
        self.d.ellipse([(cx - rx) * S, (cy - ry) * S, (cx + rx) * S, (cy + ry) * S], fill=fill, outline=oc,
                       width=int(width * S))

    def line(self, pts, c, a=1.0, w=4):
        self.d.line([(x * S, y * S) for x, y in pts], fill=self.col(c, a), width=max(1, int(w * S)), joint="curve")

    def poly(self, pts, c, a=1.0):
        if len(pts) >= 3:
            self.d.polygon([(x * S, y * S) for x, y in pts], fill=self.col(c, a))

    def arc(self, cx, cy, r, start, end, c, a=1.0, w=10):
        self.d.arc([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], start, end, fill=self.col(c, a),
                   width=int(w * S))

    def result(self):
        return self.img.reduce(S)


def wrap_lines(L, text, font, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if L.tw(test, font) <= max_w or not cur:
            cur = test
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


# ------------------------------------------------------------------- icônes
def draw_icon(L, name, cx, cy, s, t):
    if name == "target":
        radii = [1.0, 0.74, 0.48, 0.22]
        for i, r in enumerate(radii):
            p = out_back((t - 0.1 - i * 0.18) / 0.5)
            c = ACCENT if i % 2 == 0 else DARK
            L.ellipse(cx, cy, s * r * p, s * r * p, c, 1.0)
        pa = out_cubic((t - 1.1) / 0.6)
        if pa > 0:
            sx, sy = cx + s * 1.5, cy - s * 1.4
            ex, ey = sx + (cx - sx) * pa, sy + (cy - sy) * pa
            L.line([(sx, sy), (ex, ey)], WHITE, 1.0, 7)
            for k in (0.0, 0.06):
                L.line([(sx + (ex - sx) * k, sy + (ey - sy) * k),
                        (sx + (ex - sx) * k + 26, sy + (ey - sy) * k - 6)], ACCENT_SOFT, 1.0, 6)
    elif name == "steps":
        n, bw = 5, s * 0.5
        base = cy + s * 0.9
        x0 = cx - n * bw / 2
        tops = []
        for i in range(n):
            p = out_cubic((t - 0.1 - i * 0.2) / 0.45)
            h = (i + 1) * s * 0.32
            L.rect(x0 + i * bw, base - h * p, x0 + (i + 1) * bw - 6, base, ACCENT if i == n - 1 else (74, 74, 86), 1.0, r=6)
            tops.append((x0 + i * bw + bw / 2 - 3, base - h - 18))
        u = clamp((t - 1.3) / 2.6) * (n - 1)
        i = min(int(u), n - 2)
        f = u - i
        px = tops[i][0] + (tops[i + 1][0] - tops[i][0]) * f
        py = tops[i][1] + (tops[i + 1][1] - tops[i][1]) * f - math.sin(math.pi * f) * 26
        L.ellipse(px, py, 16, 16, WHITE, 1.0)
        if u >= n - 1.01:
            fx, fy = tops[-1]
            L.line([(fx, fy), (fx, fy - 70)], WHITE, 1.0, 5)
            L.poly([(fx, fy - 70), (fx + 46, fy - 55), (fx, fy - 40)], ACCENT, 1.0)
    elif name == "clock":
        p = out_back(t / 0.6)
        r = s * p
        L.ellipse(cx, cy, r, r, (24, 24, 29), 1.0, outline=ACCENT, width=10)
        for k in range(12):
            a = math.radians(k * 30 - 90)
            L.line([(cx + math.cos(a) * r * 0.82, cy + math.sin(a) * r * 0.82),
                    (cx + math.cos(a) * r * 0.92, cy + math.sin(a) * r * 0.92)], WHITE, 1.0, 5)
        am = math.radians(-90 + 360 * (t / 3.0))
        ah = math.radians(-90 + 30 * (t / 3.0))
        L.line([(cx, cy), (cx + math.cos(am) * r * 0.74, cy + math.sin(am) * r * 0.74)], WHITE, 1.0, 7)
        L.line([(cx, cy), (cx + math.cos(ah) * r * 0.5, cy + math.sin(ah) * r * 0.5)], ACCENT, 1.0, 10)
        L.ellipse(cx, cy, 11, 11, ACCENT, 1.0)
    elif name == "hourglass":
        w, h = s * 0.7, s * 1.05
        u = (t % 5.0) / 5.0
        p = out_cubic(t / 0.5)
        L.poly([(cx - w, cy - h), (cx + w, cy - h), (cx, cy)], (60, 60, 72), p)
        L.poly([(cx - w, cy + h), (cx + w, cy + h), (cx, cy)], (60, 60, 72), p)
        ws = w * (1 - u)
        L.poly([(cx - ws, cy - h * (1 - u)), (cx + ws, cy - h * (1 - u)), (cx, cy)], ACCENT, p)
        L.poly([(cx - w * u, cy + h), (cx + w * u, cy + h), (cx, cy + h - h * u)], ACCENT, p)
        if u < 0.98:
            L.line([(cx, cy), (cx, cy + h - h * u)], ACCENT_SOFT, p, 4)
        L.rect(cx - w - 14, cy - h - 18, cx + w + 14, cy - h, WHITE, p, r=6)
        L.rect(cx - w - 14, cy + h, cx + w + 14, cy + h + 18, WHITE, p, r=6)
    elif name == "mountain":
        p = out_cubic(t / 0.8)
        base = cy + s * 0.9
        L.poly([(cx - s * 1.5, base), (cx - s * 0.2, base - s * 1.5 * p), (cx + s * 0.9, base)], (60, 62, 76), 1.0)
        L.poly([(cx - s * 0.3, base), (cx + s * 0.7, base - s * 1.1 * p), (cx + s * 1.6, base)], (82, 84, 100), 1.0)
        top = (cx - s * 0.2, base - s * 1.5 * p)
        L.poly([top, (top[0] - s * 0.2, top[1] + s * 0.3 * p), (top[0] + s * 0.2, top[1] + s * 0.3 * p)], WHITE, 1.0)
        pf = out_cubic((t - 0.9) / 0.5)
        if pf > 0:
            L.line([top, (top[0], top[1] - 80 * pf)], WHITE, 1.0, 5)
            L.poly([(top[0], top[1] - 80 * pf), (top[0] + 50 * pf, top[1] - 64 * pf), (top[0], top[1] - 48 * pf)], ACCENT, 1.0)
    elif name == "bulb":
        p = out_back(t / 0.6)
        pulse = 0.5 + 0.5 * math.sin(t * 3)
        r = s * 0.62 * p
        for k in range(8):
            a = math.radians(k * 45)
            L.line([(cx + math.cos(a) * r * 1.35, cy - s * 0.25 + math.sin(a) * r * 1.35),
                    (cx + math.cos(a) * r * 1.75, cy - s * 0.25 + math.sin(a) * r * 1.75)], ACCENT_SOFT, 0.45 + 0.5 * pulse, 6)
        L.ellipse(cx, cy - s * 0.25, r, r, ACCENT_SOFT, 1.0)
        L.rect(cx - r * 0.45, cy - s * 0.25 + r * 0.8, cx + r * 0.45, cy - s * 0.25 + r * 1.25, (90, 90, 104), 1.0, r=5)
        L.rect(cx - r * 0.35, cy - s * 0.25 + r * 1.28, cx + r * 0.35, cy - s * 0.25 + r * 1.5, (70, 70, 82), 1.0, r=5)


# ------------------------------------------------------------------- scènes
def scene_hook(L, t, d, sc):
    toks = parse_marked(sc["text"])
    size = sc.get("size", 96)
    font = L.font("serifb", size)
    space = L.tw(" ", font)
    lines, cur, cw = [], [], 0
    for w, acc in toks:
        ww = L.tw(w, font)
        if cur and cw + space + ww > 1500:
            lines.append(cur)
            cur, cw = [], 0
        cw += (space if cur else 0) + ww
        cur.append((w, acc, ww))
    lines.append(cur)
    lh = size * 1.32
    y0 = L.h / 2 - len(lines) * lh / 2
    n = sum(len(x) for x in lines)
    ramp = min(d * 0.55, 0.13 * n + 0.4)
    idx = 0
    for li, line in enumerate(lines):
        total = sum(w for _, _, w in line) + space * (len(line) - 1)
        x = (L.w - total) / 2
        for w, acc, ww in line:
            ws = 0.2 + idx / max(1, n) * ramp
            p = out_cubic((t - ws) / 0.5)
            L.text(x, y0 + li * lh + 26 * (1 - p), w, font, ACCENT if acc else WHITE, p)
            x += ww + space
            idx += 1
    pu = out_cubic((t - 0.2 - ramp) / 0.7)
    if pu > 0:
        L.rect(L.w / 2 - 140 * pu, y0 + len(lines) * lh + 8, L.w / 2 + 140 * pu, y0 + len(lines) * lh + 12, ACCENT, 1.0)


def scene_stat(L, t, d, sc):
    v = float(sc["value"])
    dec = sc.get("decimals", 0)
    p = out_cubic(t / 2.4)
    cur = v * p
    txt = sc.get("prefix", "") + fmt_num(cur, dec) + sc.get("suffix", "")
    cx, cy = L.w / 2, L.h / 2 - 50
    if sc.get("ring"):
        r = 245
        L.arc(cx, cy, r, 0, 360, MUTED, 0.25, 16)
        L.arc(cx, cy, r, -90, -90 + 360 * clamp(cur / 100.0), ACCENT, 1.0, 16)
    big = L.font("serifb", sc.get("size", 230))
    L.text(cx, cy, txt, big, ACCENT, out_cubic(t / 0.4), anchor="mm")
    lab = L.font("sansb", 44)
    la = out_cubic((t - 0.9) / 0.6)
    for i, ln in enumerate(wrap_lines(L, sc.get("label", ""), lab, 1400)):
        L.text(cx, L.h - 120 + i * 58 + 14 * (1 - la), ln, lab, WHITE, la, anchor="mm")


def scene_bars(L, t, d, sc):
    bars = sc["bars"]
    n = len(bars)
    maxv = max(b["value"] for b in bars)
    minh = sc.get("minh", 0.05)
    unit = sc.get("unit", "")
    dec = sc.get("decimals", 1)
    base = L.h - 150
    maxh = L.h - 290
    bw = 270
    gap = 150
    total = n * bw + (n - 1) * gap
    x0 = (L.w - total) / 2
    lab = L.font("sansb", 34)
    val = L.font("serifb", 62)
    L.line([(x0 - 40, base + 4), (x0 + total + 40, base + 4)], MUTED, 0.6, 3)
    for i, b in enumerate(bars):
        p = out_cubic((t - 0.3 - i * 0.5) / 1.0)
        h = max(minh, b["value"] / maxv) * maxh * p
        x = x0 + i * (bw + gap)
        c = ACCENT if b.get("hl") else (86, 88, 102)
        L.rect(x, base - h, x + bw, base, c, 1.0, r=10)
        L.text(x + bw / 2, base - h - 14, fmt_num(b["value"] * p, dec) + unit, val, WHITE if b.get("hl") else ACCENT_SOFT, min(1, p * 3),
               anchor="md")
        la = out_cubic((t - 0.5 - i * 0.5) / 0.6)
        for k, ln in enumerate(wrap_lines(L, b["label"], lab, bw + gap - 20)):
            L.text(x + bw / 2, base + 42 + k * 42, ln, lab, WHITE if b.get("hl") else MUTED, la, anchor="mm")


def scene_quote(L, t, d, sc):
    font = L.font("serif", 60)
    qm = L.font("serifb", 300)
    L.text(210, 190, "\u201c", qm, ACCENT, 0.55 * out_cubic(t / 0.6), anchor="lm", shadow=False)
    lines = wrap_lines(L, sc["quote"], font, 1280)
    lh = 84
    y0 = L.h / 2 - len(lines) * lh / 2 - 20
    words_all = [(li, w) for li, ln in enumerate(lines) for w in ln.split()]
    n = len(words_all)
    ramp = min(d * 0.6, 0.18 * n + 0.5)
    idx = 0
    for li, ln in enumerate(lines):
        x = 320
        for w in ln.split():
            ws = 0.4 + idx / max(1, n) * ramp
            p = out_cubic((t - ws) / 0.5)
            L.text(x, y0 + li * lh + 14 * (1 - p), w, font, WHITE, p)
            x += L.tw(w + " ", font)
            idx += 1
    pa = out_cubic((t - 0.6 - ramp) / 0.6)
    ay = y0 + len(lines) * lh + 36
    L.rect(320, ay + 22, 320 + 80 * pa, ay + 25, ACCENT, 1.0)
    L.text(420, ay + 24, sc.get("author", ""), L.font("sansb", 38), ACCENT_SOFT, pa, anchor="lm")


def scene_rule(L, t, d, sc):
    icon_cx, icon_cy, icon_s = 480, L.h / 2 + 10, 190
    L.ellipse(icon_cx, icon_cy, 285, 285, PANEL, 0.7 * out_cubic(t / 0.5))
    draw_icon(L, sc.get("icon", "target"), icon_cx, icon_cy, icon_s, t)
    a = out_cubic((t - 0.2) / 0.6)
    lf = L.font("sansb", 42)
    L.text(880, 170 + 16 * (1 - a), sc.get("label", "RÈGLE"), lf, ACCENT, a, shadow=False, anchor="lm")
    if sc.get("number") is not None:
        nx = 880 + L.tw(sc.get("label", "RÈGLE"), lf) + 26
        L.text(nx, 170 + 16 * (1 - a), str(sc["number"]), L.font("serifb", 70), WHITE, a, shadow=False, anchor="lm")
    L.rect(880, 215, 880 + 100 * a, 219, ACCENT, 1.0)
    font = L.font("serifb", sc.get("size", 70))
    lines = wrap_lines(L, sc["title"], font, 900)
    for i, ln in enumerate(lines):
        p = out_cubic((t - 0.55 - i * 0.3) / 0.6)
        L.text(880, 255 + i * 92 + 18 * (1 - p), ln, font, WHITE, p)


def scene_list(L, t, d, sc):
    items = sc["items"]
    a = out_cubic(t / 0.5)
    L.tracked(L.w / 2, 40, sc.get("label", "À RETENIR"), L.font("sansb", 36), ACCENT, a, 8)
    font = L.font("sansb", 62)
    row = 120
    y0 = 150
    for i, it in enumerate(items):
        p = out_cubic((t - 0.5 - i * 0.9) / 0.6)
        if p <= 0:
            continue
        y = y0 + i * row
        x = 380 + 40 * (1 - p)
        L.rect(x - 60, y - 44, x + 1120, y + 44, PANEL, 0.9 * p, r=18)
        L.ellipse(x, y, 34, 34, ACCENT, p)
        L.line([(x - 15, y + 1), (x - 4, y + 13), (x + 17, y - 12)], DARK, p, 8)
        L.text(x + 64, y, it, font, WHITE, p, anchor="lm")


def scene_versus(L, t, d, sc):
    cols = [("left", MUTED, 470), ("right", ACCENT, 1450)]
    a = out_cubic(t / 0.6)
    L.rect(L.w / 2 - 2, 70 * a, L.w / 2 + 2, L.h - 70 * a, MUTED, 0.5)
    tf = L.font("serifb", 66)
    lf = L.font("sansb", 44)
    for k, (key, col, cx) in enumerate(cols):
        side = sc[key]
        p = out_cubic((t - 0.3 - k * 0.5) / 0.7)
        L.text(cx, 110 + 20 * (1 - p), side["title"], tf, col if col == ACCENT else WHITE, p, anchor="mm")
        L.rect(cx - 90 * p, 170, cx + 90 * p, 174, col, 1.0)
        for i, ln in enumerate(side["lines"]):
            q = out_cubic((t - 1.0 - k * 0.5 - i * 0.6) / 0.6)
            for j, seg in enumerate(wrap_lines(L, ln, lf, 760)):
                L.text(cx, 260 + i * 130 + j * 52 + 16 * (1 - q), seg, lf, WHITE if key == "right" else (205, 205, 212), q, anchor="mm")


def scene_outro(L, t, d, sc):
    a = out_cubic(t / 0.6)
    L.text(L.w / 2, 190 + 20 * (1 - a), sc.get("text", "Abonne-toi"), L.font("serifb", 130), ACCENT, a, anchor="mm")
    p = out_back((t - 0.8) / 0.6)
    pulse = 1 + 0.04 * math.sin(t * 4)
    bw, bh = 460 * p * pulse, 120 * p * pulse
    L.rect(L.w / 2 - bw / 2, 330 - bh / 2, L.w / 2 + bw / 2, 330 + bh / 2, ACCENT, 1.0, r=30)
    if p > 0.8:
        L.text(L.w / 2, 330, "S'ABONNER", L.font("sansb", 50), DARK, 1.0, anchor="mm", shadow=False)
    b = out_cubic((t - 1.6) / 0.6)
    L.text(L.w / 2, 500, sc.get("sub", ""), L.font("sans", 46), WHITE, b, anchor="mm")


SCENES = {"hook": scene_hook, "stat": scene_stat, "bars": scene_bars, "quote": scene_quote, "rule": scene_rule,
          "list": scene_list, "versus": scene_versus, "outro": scene_outro}


# ----------------------------------------------------------------- rendu
class Renderer:
    def __init__(self, header, series, brand, scenes, captions, total):
        self.fonts = Fonts()
        self.header, self.series, self.brand = header, series, brand
        self.scenes, self.captions, self.total = scenes, captions, total
        self.glow = glow_sprite(900, 2.4)
        self.dot = [glow_sprite(s) for s in (12, 20, 32)]
        rnd = random.Random(7)
        self.parts = [dict(x=rnd.uniform(0, W), y=rnd.uniform(0, H), vy=rnd.uniform(6, 20), amp=rnd.uniform(6, 26),
                           ph=rnd.uniform(0, 6.28), sp=rnd.uniform(0.12, 0.5), tw=rnd.uniform(0.5, 1.4),
                           k=rnd.choice([0, 0, 1, 1, 2])) for _ in range(45)]
        self.bg = self._make_bg()
        self.cap_layout = [self._cap_layout(c["text"]) for c in captions]

    # -- fond statique + en-tête
    def _make_bg(self):
        strip = Image.new("RGB", (1, H))
        for y in range(H):
            strip.putpixel((0, y), lerp(BG_TOP, BG_BOT, y / (H - 1)))
        img = strip.resize((W, H), Image.NEAREST)
        vg = Image.radial_gradient("L").resize((W, H), Image.BILINEAR).point(lambda v: min(255, int(v * 1.05)))
        img = Image.composite(Image.new("RGB", (W, H), (3, 3, 6)), img, vg.point(lambda v: int(max(0, v - 120) * 1.4)))
        d = ImageDraw.Draw(img, "RGBA")
        f = self.fonts
        # série (capitales espacées)
        sf = f.get("sansb", 26)
        spacing = 7
        s = self.series.upper()
        ws = [d.textlength(ch, font=sf) for ch in s]
        x = (W - (sum(ws) + spacing * (len(s) - 1))) / 2
        for ch, w in zip(s, ws):
            d.text((x, 34), ch, font=sf, fill=ACCENT + (255,))
            x += w + spacing
        # titre
        size = 64
        tf = f.get("serifb", size)
        while d.textlength(self.header, font=tf) > 1500 and size > 36:
            size -= 4
            tf = f.get("serifb", size)
        d.text((W / 2, 112), self.header, font=tf, fill=WHITE + (255,), anchor="mm")
        d.rectangle([360, 168, W - 360, 170], fill=ACCENT + (255,))
        d.rectangle([360, CAP_Y - 24, W - 360, CAP_Y - 22], fill=ACCENT + (255,))
        d.text((W - 60, H - 34), self.brand, font=f.get("sansb", 24), fill=MUTED + (255,), anchor="rm")
        return img

    # -- sous-titres
    def _cap_layout(self, text):
        d = ImageDraw.Draw(Image.new("RGB", (8, 8)))
        size = 56
        while True:
            font = self.fonts.get("sansb", size)
            sp = d.textlength(" ", font=font)
            lines, cur, cw = [], [], 0
            for w in text.split():
                ww = d.textlength(w, font=font)
                if cur and cw + sp + ww > 1640:
                    lines.append(cur)
                    cur, cw = [], 0
                cw += (sp if cur else 0) + ww
                cur.append((w, ww))
            lines.append(cur)
            if len(lines) <= 2 or size <= 38:
                break
            size -= 4
        lh = size * 1.28
        y0 = CAP_Y + (H - CAP_Y - 36) / 2 - len(lines) * lh / 2 + 6
        words, total_chars = [], sum(len(w) for ln in lines for w, _ in ln)
        acc = 0
        for li, ln in enumerate(lines):
            tw = sum(w for _, w in ln) + sp * (len(ln) - 1)
            x = (W - tw) / 2
            for w, ww in ln:
                words.append((w, x, y0 + li * lh, acc / total_chars, (acc + len(w)) / total_chars))
                acc += len(w)
                x += ww + sp
        return font, words

    def _captions(self, im, t):
        dr = ImageDraw.Draw(im, "RGBA")
        for c, (font, words) in zip(self.captions, self.cap_layout):
            s, e = c["start"], c["start"] + c["speech"]
            if t < s - 0.08 or t > e + 0.35:
                continue
            a = smooth((t - (s - 0.08)) / 0.2) * (1 - smooth((t - (e + 0.15)) / 0.2))
            u = clamp((t - s) / max(0.1, c["speech"]))
            for w, x, y, u0, u1 in words:
                if u >= u1:
                    col = WHITE
                elif u >= u0:
                    col = ACCENT
                else:
                    col = (140, 142, 152)
                dr.text((x + 2, y + 3), w, font=font, fill=(0, 0, 0, int(160 * a)))
                dr.text((x, y), w, font=font, fill=col + (int(255 * a),))

    # -- ambiance
    def _ambient(self, im, t):
        a = 0.16 + 0.05 * math.sin(t * 0.7)
        lut = [int(v * a) for v in range(256)]
        im.paste(ACCENT, (W // 2 - 450, SCN_Y + SCN_H // 2 - 450), self.glow.point(lut))
        for p in self.parts:
            y = (p["y"] - p["vy"] * t) % H
            x = p["x"] + p["amp"] * math.sin(t * p["sp"] + p["ph"])
            al = 0.15 + 0.5 * (0.5 + 0.5 * math.sin(t * p["tw"] * 2 + p["ph"]))
            sprite = self.dot[p["k"]]
            lut = [int(v * al) for v in range(256)]
            s = sprite.size[0]
            im.paste(ACCENT_SOFT, (int(x - s / 2), int(y - s / 2)), sprite.point(lut))

    def _scene_at(self, t):
        for sc in self.scenes:
            if sc["start"] <= t < sc["end"]:
                return sc
        return self.scenes[-1] if t >= self.scenes[-1]["end"] else None

    def frame(self, t):
        im = self.bg.copy()
        self._ambient(im, t)
        sc = self._scene_at(t)
        if sc is not None:
            crop = im.crop((0, SCN_Y, W, SCN_Y + SCN_H))
            L = Layer(crop, W, SCN_H, self.fonts)
            SCENES[sc["type"]](L, t - sc["start"], sc["end"] - sc["start"], sc)
            res = L.result()
            a = min(smooth((t - sc["start"]) / 0.35), 1 - smooth((t - (sc["end"] - 0.25)) / 0.25))
            if a < 1:
                res = Image.blend(crop, res, clamp(a))
            im.paste(res, (0, SCN_Y))
        self._captions(im, t)
        dr = ImageDraw.Draw(im, "RGBA")
        dr.rectangle([0, H - 6, int(W * clamp(t / self.total)), H], fill=ACCENT + (200,))
        fade = min(smooth(t / 0.4), 1 - smooth((t - (self.total - 0.8)) / 0.8))
        if fade < 1:
            im = Image.blend(Image.new("RGB", (W, H), (0, 0, 0)), im, clamp(fade))
        return im


# --------------------------------------------------------------- miniature
def make_thumbnail(path, text, brand, series):
    """Miniature 1280x720 : mots-clés très gros, accent ambre."""
    k = 1280 / W
    f = Fonts()
    strip = Image.new("RGB", (1, 720))
    for y in range(720):
        strip.putpixel((0, y), lerp((14, 14, 20), (40, 30, 20), y / 719))
    img = strip.resize((1280, 720), Image.NEAREST)
    img.paste(ACCENT, (640 - 450, 360 - 450), glow_sprite(900, 2.6).point(lambda v: int(v * 0.35)))
    d = ImageDraw.Draw(img, "RGBA")
    toks = parse_marked(text)
    size = 140
    while True:
        font = f.get("serifb", size)
        sp = d.textlength(" ", font=font)
        lines, cur, cw = [], [], 0
        for w, acc in toks:
            ww = d.textlength(w, font=font)
            if cur and cw + sp + ww > 1120:
                lines.append(cur)
                cur, cw = [], 0
            cw += (sp if cur else 0) + ww
            cur.append((w, acc, ww))
        lines.append(cur)
        if (len(lines) <= 2 and len(lines) * size * 1.18 <= 520) or size <= 70:
            break
        size -= 10
    lh = size * 1.18
    y = 360 - len(lines) * lh / 2 + 10
    for ln in lines:
        tw = sum(w for _, _, w in ln) + sp * (len(ln) - 1)
        x = (1280 - tw) / 2
        for w, acc, ww in ln:
            d.text((x + 5, y + 6), w, font=font, fill=(0, 0, 0, 200))
            d.text((x, y), w, font=font, fill=(ACCENT if acc else WHITE) + (255,))
            x += ww + sp
        y += lh
    d.rectangle([420, 60, 860, 66], fill=ACCENT + (255,))
    d.text((640, 40), series.upper(), font=f.get("sansb", 30), fill=ACCENT_SOFT + (255,), anchor="mm")
    d.text((1230, 690), brand, font=f.get("sansb", 28), fill=MUTED + (255,), anchor="rm")
    img.save(path)
