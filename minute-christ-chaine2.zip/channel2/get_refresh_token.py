#!/usr/bin/env python3
"""À lancer UNE SEULE FOIS sur votre ordinateur pour obtenir le refresh token YouTube.

    pip install google-auth-oauthlib
    python get_refresh_token.py client_secret.json

Une fenêtre de navigateur s'ouvre : connectez-vous avec le compte propriétaire de la chaîne
"La Minute du Christ" et acceptez. Le script affiche ensuite les 3 valeurs à copier dans
les secrets GitHub.
"""
import json
import sys

from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

path = sys.argv[1] if len(sys.argv) > 1 else "client_secret.json"
flow = InstalledAppFlow.from_client_secrets_file(path, SCOPES)
creds = flow.run_local_server(port=0, access_type="offline", prompt="consent")

secret = json.load(open(path))
conf = secret.get("installed") or secret.get("web")
print("\n=== À copier dans GitHub > Settings > Secrets and variables > Actions ===")
print("YT_CLIENT_ID     =", conf["client_id"])
print("YT_CLIENT_SECRET =", conf["client_secret"])
print("YT_REFRESH_TOKEN =", creds.refresh_token)
