#!/usr/bin/env python3
"""Décide si une vidéo doit être publiée aujourd'hui (jours calendaires UTC).

Le workflow tourne chaque jour à 13h00 UTC ; ce script n'autorise une publication que si
au moins INTERVAL_DAYS jours calendaires se sont écoulés depuis la dernière.
Écrit publish=true|false dans $GITHUB_OUTPUT.
"""
import json
import os
from datetime import datetime, timezone
from pathlib import Path

INTERVAL_DAYS = 2  # une vidéo tous les 2 jours

state = json.loads((Path(__file__).parent / "state.json").read_text())
last = state.get("last_published")
force = os.environ.get("FORCE", "false").lower() == "true"

publish = True
if last and not force:
    last_day = datetime.fromisoformat(last).date()
    today = datetime.now(timezone.utc).date()
    days = (today - last_day).days
    publish = days >= INTERVAL_DAYS
    print(f"Dernière publication : {last} ({days} jour(s) calendaires)")
else:
    print("Première publication ou exécution forcée")

print("publish =", publish)
out = os.environ.get("GITHUB_OUTPUT")
if out:
    with open(out, "a") as f:
        f.write(f"publish={'true' if publish else 'false'}\n")
