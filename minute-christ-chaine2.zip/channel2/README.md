# Chaîne motivation : publication automatique (gratuit)

Une vidéo YouTube **horizontale 16:9 de ~3 min 20** (animée, voix off, sous-titres surlignés, chapitres, miniature) est créée et publiée **en public tous les 2 jours à 13h00 (UTC)**.

## Installation (même méthode que la chaîne de prière, avec le compte Google de CETTE chaîne)

1. **Nouveau dépôt GitHub privé** : `motivation` (github.com/new). Envoyez-y tous les fichiers de ce dossier, y compris `.github/workflows/publish.yml` (créez-le avec l'adresse `…/new/main?filename=.github/workflows/publish.yml`).
2. **Google Cloud** : avec le compte Google de la chaîne motivation, créez un projet, activez **YouTube Data API v3**, configurez l'écran de consentement (Externe), publiez l'application, créez un **ID client OAuth « Application Web »** avec l'URI de redirection `https://developers.google.com/oauthplayground`.
3. **Refresh token** : dans OAuth Playground (avec vos propres identifiants), scope `https://www.googleapis.com/auth/youtube.upload`, connectez-vous avec le compte de la chaîne motivation, puis « Exchange authorization code for tokens ».
4. **Secrets GitHub** du dépôt : `YT_CLIENT_ID`, `YT_CLIENT_SECRET`, `YT_REFRESH_TOKEN`.
5. **Test** : Actions > Publier la vidéo > Exécuter le flux de travail > cochez « Publier maintenant ». Comptez 15 à 25 minutes pour la première exécution.

## À savoir
- **Miniature personnalisée** : YouTube la demande si la chaîne est **vérifiée** (youtube.com/verify, par SMS, gratuit). Sinon la vidéo est publiée quand même, avec une miniature choisie par YouTube.
- **Vidéos privées** : tant que le projet API n'est pas audité par Google, les vidéos envoyées par API peuvent rester en privé. Passez-les en public à la main dans YouTube Studio.
- **Contenu** : `scripts.json` contient les vidéos. Quand la liste est épuisée, elle recommence : ajoutez-en régulièrement.
- **Marque** : changez `BRAND` et `SERIES` (variables d'environnement dans le workflow ou valeurs par défaut en haut de `build.py`).
- **Musique** : déposez un fichier `music.mp3` libre de droits à la racine, il sera ajouté en sourdine.
- **Test local** : `python build.py --dry` (voix remplacée par du silence).
