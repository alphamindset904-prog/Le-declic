#!/usr/bin/env python3
"""Publie out/video.mp4 sur YouTube en PUBLIC via l'API YouTube Data v3 (gratuite).

Variables d'environnement requises (secrets GitHub) :
    YT_CLIENT_ID, YT_CLIENT_SECRET, YT_REFRESH_TOKEN
"""
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

ROOT = Path(__file__).resolve().parent
meta = json.loads((ROOT / "out" / "meta.json").read_text(encoding="utf-8"))

creds = Credentials(
    token=None,
    refresh_token=os.environ["YT_REFRESH_TOKEN"],
    client_id=os.environ["YT_CLIENT_ID"],
    client_secret=os.environ["YT_CLIENT_SECRET"],
    token_uri="https://oauth2.googleapis.com/token",
    scopes=["https://www.googleapis.com/auth/youtube.upload"],
)
youtube = build("youtube", "v3", credentials=creds, cache_discovery=False)

body = {
    "snippet": {
        "title": meta["title"],
        "description": meta["description"],
        "tags": meta["tags"],
        "categoryId": "27",  # Education
        "defaultLanguage": "fr",
        "defaultAudioLanguage": "fr",
    },
    "status": {
        "privacyStatus": meta.get("privacy", "public"),
        "selfDeclaredMadeForKids": False,
        "embeddable": True,
    },
}

media = MediaFileUpload(meta["video"], mimetype="video/mp4", chunksize=8 * 1024 * 1024, resumable=True)
request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)

response = None
while response is None:
    status, response = request.next_chunk()
    if status:
        print(f"Envoi : {int(status.progress() * 100)} %", flush=True)

video_id = response["id"]
print(f"Publié : https://www.youtube.com/watch?v={video_id}")

# Miniature personnalisée (nécessite une chaîne vérifiée par téléphone ; un échec n'arrête pas la publication)
thumb = meta.get("thumbnail")
if thumb and Path(thumb).exists():
    try:
        youtube.thumbnails().set(videoId=video_id, media_body=MediaFileUpload(thumb, mimetype="image/png")).execute()
        print("Miniature ajoutée")
    except Exception as e:  # noqa: BLE001
        print("Miniature non ajoutée (vérifiez la chaîne sur youtube.com/verify) :", str(e)[:200])

# Mémorise la publication (state.json est ensuite commité par le workflow)
state_path = ROOT / "state.json"
state = json.loads(state_path.read_text())
state["next_index"] = meta["index"] + 1
state["last_published"] = datetime.now(timezone.utc).isoformat()
state.setdefault("history", []).append(
    {"video_id": video_id, "title": meta["title"], "published": state["last_published"]}
)
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

# Pour le résumé GitHub Actions
summary = os.environ.get("GITHUB_STEP_SUMMARY")
if summary:
    with open(summary, "a") as f:
        f.write(f"### Vidéo publiée\nhttps://www.youtube.com/watch?v={video_id}\n")
sys.exit(0)
